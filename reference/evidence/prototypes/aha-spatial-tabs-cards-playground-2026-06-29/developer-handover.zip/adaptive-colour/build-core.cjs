const fs = require("node:fs");
const path = require("node:path");
const compiler = require(process.env.ESBUILD_MODULE || "esbuild");
const source = fs.readFileSync(path.join(__dirname, "gradient-colour.js"), "utf8");
const code = compiler.transformSync(source, { loader: "js", target: "es2020", charset: "utf8", legalComments: "none", minify: true }).code;
const target = path.join(__dirname, "gradient-colour.min.js");
if (process.argv.includes("--check")) {
  if (fs.readFileSync(target, "utf8") !== code) throw new Error("Minified engine is stale.");
} else fs.writeFileSync(target, code);
